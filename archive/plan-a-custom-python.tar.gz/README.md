# 🤖 Multi-Node AI Agent System — 双节点多角色协作部署方案

两套跨服务器 AI 多角色协作系统的完整部署方案，均基于实际部署经验编写。

## 项目背景

在阿里云 ECS（香港）和 AWS EC2（东京）两台服务器上部署 AI 多角色协作系统，实现：

- **多角色分工**：规划、起草、审查、信息搜集各司其职
- **双模型对抗**：Qwen (HK) vs DeepSeek (AWS) 同题竞争出方案
- **交叉审查**：A 的方案由 B 审查，B 的方案由 A 审查
- **跨服务器调度**：中控通过 SSH/Cloudflare/直连调度远程 worker

## 两套方案

### [Plan A: 自定义 Python 系统](plan-a-custom/)

纯 Python 实现的四角色协作系统，不依赖任何第三方 agent 框架。

```
用户 → Telegram Bot → Pipeline Engine
                        ├── Planner (任务拆解)
                        ├── Researcher (信息搜集)
                        ├── Executor (任务执行)
                        └── Reviewer (质量审查 + 反馈循环)
```

**适用场景**：想要完全掌控架构、深度定制、不想绑定特定框架

### [Plan B: 官方 OpenClaw 双节点部署](plan-b-openclaw/) ✅ 已部署

基于 OpenClaw 官方框架的七角色双节点系统，**已在生产环境跑通**。

```
用户 → Telegram → HK 中控 (Planner/Qwen)
                    ├── spawn Drafter-A (Qwen)
                    ├── spawn Researcher (Qwen)
                    ├── spawn Reviewer-HK (Qwen)
                    └── webhook/SSH → AWS Tokyo
                         ├── Drafter-B (DeepSeek Chat)
                         ├── Critic (DeepSeek R1)
                         └── Overseas-Researcher (DeepSeek)
```

**适用场景**：快速上线、利用 OpenClaw 生态、需要 webhook/channel 集成

## 方案对比

| 维度 | Plan A: 自定义 Python | Plan B: 官方 OpenClaw |
|------|---------------------|---------------------|
| 架构 | 自建 pipeline + LLM client | OpenClaw gateway + agents |
| 配置 | 自定义 JSON schema | openclaw.json 官方格式 |
| 模型调用 | 统一 LLM 客户端 (OpenAI 兼容) | 内置 model routing |
| Telegram | python-telegram-bot | OpenClaw channel adapter |
| 跨服务器 | 预留接口 (未实现) | webhook + SSH + CF Tunnel |
| 学习曲线 | 代码即文档，完全透明 | 需熟悉 OpenClaw 概念 |
| 状态 | 已设计，可部署 | **已部署并验证** |

## 服务器环境

| 节点 | 平台 | 规格 | 系统 | 用途 |
|------|------|------|------|------|
| HK 中控 | 阿里云 ECS 香港 | 2C4G | Ubuntu 24.04 | 中控 + Telegram |
| AWS Worker | AWS EC2 东京 | t3.medium | Ubuntu 24.04 | DeepSeek worker |

## 踩坑总结

部署过程中的关键经验教训，详见 [LESSONS.md](LESSONS.md)

## 目录结构

```
.
├── README.md                    # 本文件
├── LESSONS.md                   # 踩坑记录
├── plan-a-custom/               # Plan A: 自定义 Python 系统
│   ├── README.md
│   ├── setup.sh                 # 部署脚本
│   ├── config/
│   │   ├── openclaw.json        # 主配置
│   │   └── remote-workers.json  # 远程 worker 配置
│   ├── roles/                   # 角色 prompt 定义
│   │   ├── planner.md
│   │   ├── executor.md
│   │   ├── researcher.md
│   │   └── reviewer.md
│   ├── scripts/                 # 管理脚本
│   └── core/openclaw/           # Python 核心代码
│       ├── main.py
│       ├── pipeline.py
│       ├── llm.py
│       ├── config.py
│       ├── models.py
│       └── telegram_bot.py
│
└── plan-b-openclaw/             # Plan B: 官方 OpenClaw 部署
    ├── README.md
    ├── deploy-hk.sh             # HK 中控部署脚本
    ├── deploy-aws.sh            # AWS worker 部署脚本
    ├── scripts/
    │   ├── aws-task.sh          # HK→AWS 任务调度封装
    │   └── read-result.py       # AWS 结果读取脚本
    ├── soul-templates/          # 各角色 SOUL.md 模板
    │   ├── planner.md
    │   ├── drafter-a.md
    │   ├── drafter-b.md
    │   ├── researcher.md
    │   ├── reviewer-hk.md
    │   ├── critic.md
    │   └── overseas-researcher.md
    └── config-examples/         # 配置示例
        ├── hk-openclaw.json
        └── aws-openclaw.json
```

## License

MIT
